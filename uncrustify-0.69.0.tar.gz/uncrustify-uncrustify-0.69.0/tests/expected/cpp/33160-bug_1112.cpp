::std::vector<int>& foo();
std::vector<int>& bar();
