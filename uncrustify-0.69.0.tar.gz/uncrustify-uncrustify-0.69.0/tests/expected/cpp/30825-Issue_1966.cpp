#define FLAG1               0x101  /* struct foo should not be used.
	                              The struct is unsafe */
