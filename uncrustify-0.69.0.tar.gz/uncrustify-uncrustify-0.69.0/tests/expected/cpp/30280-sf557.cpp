//test.cpp
void test_fun(std::size_t a,
              std::size_t /* b */);

