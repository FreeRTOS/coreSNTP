template< class T, unsigned N = 0 >
constexpr unsigned long extent_v = extent< T, N >::value;
