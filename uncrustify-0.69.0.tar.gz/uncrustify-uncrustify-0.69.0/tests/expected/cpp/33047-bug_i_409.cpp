if(X == Y) X = Z;
if(Y == Z) Y = X;

for (i=0; i<5; i++) foo(i);
for (i=0; i<5; i++) foo(i);

while (i<5) foo(i++);
while (i<5) foo(i++);
