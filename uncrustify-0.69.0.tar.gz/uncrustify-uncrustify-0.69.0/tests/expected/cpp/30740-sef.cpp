CFoo::CFoo(const DWORD something,
		const RECT& positionRect,
		const UINT aNumber,
		bool thisIsReadOnly,
		const CString& windowTitle,
		CInfo* pStructInfo,
		int widthOfSomething)
	: CSuperFoo(something, positionRect, aNumber,
			thisIsReadOnly, windowTitle),
	m_pInfo(pInfo),
	m_width(widthOfSomething)
{
}


// this_comment_has_a_first_word_that_is_too_long_to_fit_into_a_line_without_wrapping
// and should not start with a blank comment line.
