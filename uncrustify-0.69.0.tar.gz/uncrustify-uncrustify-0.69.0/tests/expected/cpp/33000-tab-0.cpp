/* test of
 * indent_with_tabs = 0
 * indent_columns   = 11
 * the source has many <TAB>
 */
{
           int a;
           int b;
}
