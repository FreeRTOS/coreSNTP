void foo()
{
	for_each(it.begin(), it.end(), func);
}
