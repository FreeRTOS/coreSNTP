class test_Dummy
    : public QObject
{
    Q_OBJECT
    test_Dummy* settings = nullptr;
};
