namespace
{
	enum EnumValue
	{
		EnumValue1 = 1 << 1
	};
}
