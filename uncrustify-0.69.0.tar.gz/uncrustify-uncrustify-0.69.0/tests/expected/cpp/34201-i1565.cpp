namespace ns1 {
namespace ns2 {

  #define SOME_MACRO() \
	if(true) { \
	}

} // namespace ns2
} // namespace ns1