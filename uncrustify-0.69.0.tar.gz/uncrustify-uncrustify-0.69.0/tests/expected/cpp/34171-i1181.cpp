int main()
{
	if(true) {return 1;}
	else if(true) {return 1;}
	else {return 1;}
}