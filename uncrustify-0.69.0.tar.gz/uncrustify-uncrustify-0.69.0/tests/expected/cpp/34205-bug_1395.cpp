Type tmp = call_function(getObj().x,
                         getObj().y,
                         getObj().z,
                         getObj().w);
getObj().result = tmp;
