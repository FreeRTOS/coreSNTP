int Function(
	);

int Function(
	);

int Function();