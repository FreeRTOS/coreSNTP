\
#define CTOR(i, _) : \
 T(X()), \
    y() \
{ }

