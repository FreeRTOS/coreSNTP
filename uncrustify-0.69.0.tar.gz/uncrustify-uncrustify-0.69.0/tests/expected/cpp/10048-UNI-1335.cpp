// Change in Configuration\UnityConfigure.h:

    #define FOO_MACRO 0 /////@TODO: COMMENT?????
// ^^^ space removed after 0

// Foo\Bar\Baz\Fizz\Test.cpp

    #define BAR_MACRO   FOO_BAR_MACRO //FOO_BAR_BAZ_NONE
// ^^^ space removed after _MACRO
