void f(
	int a, int b);

void g()
{
	f(1, 2);
}