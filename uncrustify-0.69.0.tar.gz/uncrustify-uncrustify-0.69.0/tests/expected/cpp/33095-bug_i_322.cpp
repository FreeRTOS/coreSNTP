class STDMETHOD
{
	STDMETHOD(GetValues)(BSTR bsName, REFDATA** pData);
};
