struct MyClass : public Foo {
  MyClass(int a, int b, int c):
      m_a(a), m_b(b), m_c(c) {}
};
