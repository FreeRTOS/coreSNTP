int i = 0; /* a b *//* a b */ int b = 0;
