class Parser::ParserPrivate {};

template <typename T> class to {};

my $all = {};

enum FocusEffect {};

struct error {};
