const int *ptr const = 0;
virtual void f1()       = 0;
virtual void f2()       = 0;
virtual void f3() const = 0;
virtual void f4() const = 0;
virtual void f5()       = 0;
virtual void f6()       = 0;
