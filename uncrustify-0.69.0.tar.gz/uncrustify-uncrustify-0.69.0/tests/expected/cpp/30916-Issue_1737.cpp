template<class T>
class foo
{
public:
T x;
foo<T>(int a) : x(a)
{
	int y = a;
	int z = 13;
}
};
