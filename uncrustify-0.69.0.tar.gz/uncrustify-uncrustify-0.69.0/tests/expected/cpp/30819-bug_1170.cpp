template<class CLASS_PARAMETER_0, class CLASS_PARAMETER_1, class CLASS_PARAMETER_2, class CLASS_PARAMETER_3, class CLASS_PARAMETER_4,
      class CLASS_PARAMETER_5>
class MyTemplateClass
{
public:
   MyTemplateClass<my::super::cool::_and::fancy::type, my::super::cool::_and::fancy::type, my::super::cool::_and::fancy::type,
         my::super::cool::_and::fancy::type, my::super::cool::_and::fancy::type, my::super::cool::_and::fancy::type> foo();
};
