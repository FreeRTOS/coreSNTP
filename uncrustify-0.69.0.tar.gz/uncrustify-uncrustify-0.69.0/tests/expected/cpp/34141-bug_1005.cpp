friend void ::test::swap< >(future< T >&, future< T >&);
