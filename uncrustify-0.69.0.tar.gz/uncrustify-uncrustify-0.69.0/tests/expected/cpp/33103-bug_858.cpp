enum
{
   item1 = 123,
   item2, // comment 2
}

enum
{
   item3,
   item4,  // comment 4
}
enum { x, y,};
enum { x, y = 0,};
enum { x, y = 0,/*comment*/ };
enum { x, y,};
enum { x, y = 0,};
enum { x, y = 0,/*comment*/ };
