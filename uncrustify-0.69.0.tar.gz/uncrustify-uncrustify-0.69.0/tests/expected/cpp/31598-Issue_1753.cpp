void x()
{
	a = c0 * d0();
	a = b ? c + d : e;
	a = b ? c * d : e;
	a = b ? c + d() : e;
	a = b1 ? c1 * d1() : e1;
	a = b2 ? c2() * d2 : e2;
}
