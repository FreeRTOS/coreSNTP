class \u005FClass // underscore character
{
};

int main()
{
	string IdentifierContainingTwoUCNCharacters\u1234\U00001234 = "\u005FClass";
}
