void f()
{
   call_a_function(42,
                   double(-1),
                   "charray");
   call_a_function(42,
                   double(-1),
                   "charray"
                   );
   call_a_function(
      42,
      double(-1),
      "charray"
      );
   call_a_template_function<int,
                            int,
                            int>
      (42);
   call_a_template_function<int,
                            int,
                            int
                            >
      (42);
   call_a_template_function<int,
                            int,
                            int>(42);
   call_a_template_function<int,
                            int,
                            int>(
      42
      );
   call_a_template_function<
      int,
      int,
      int
      >
      (42);
}
template<class T,
         class U> class W;
template<class T,
         class U
         > class X;
template<
   class T,
   class U> class Y;
template<
   class T,
   class U
   > class Z;
