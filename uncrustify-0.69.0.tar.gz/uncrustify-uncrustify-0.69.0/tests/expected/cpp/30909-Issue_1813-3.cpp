namespace n1 {
namespace n2 {
namespace n3 {

  void func() {
    another_func([]() {
      return 42;
    });
  }

}
}
}
