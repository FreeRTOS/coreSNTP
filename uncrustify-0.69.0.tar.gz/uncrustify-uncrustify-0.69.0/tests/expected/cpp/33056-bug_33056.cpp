inline T* * someFunc(foo** p, bar&& q)
{
}

inline T && someFunc(foo * *p, bar && q)
{
}
