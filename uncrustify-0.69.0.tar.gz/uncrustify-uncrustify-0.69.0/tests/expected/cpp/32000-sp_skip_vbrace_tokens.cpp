void foo()
{
    if (data)   go = new ClassA();
    else        go = new ClassB();

    if (evt.alt)        modifiers += "Alt+";
    if (evt.command)    modifiers += "Cmd+";
    if (evt.control)    modifiers += "Ctrl+";
    if (evt.shift)      modifiers += "Shift+";
}
