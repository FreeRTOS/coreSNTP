/**
 * @file cmt_insert.cpp
 * Description
 *
 * $Id$
 */
#include <string>

/**
 * CLASS:  CFoo
 * TODO: DESCRIPTION
 */
class CFoo
{
CFoo(int arg);
/**
 * CFoo
 * TODO: DESCRIPTION
 * @param arg TODO
 * @return TODO
 */
CFoo(char arg) {
}
~CFoo();
int foo1(int arg);
int foo2();
/**
 * foo3
 * TODO: DESCRIPTION
 * @param ch TODO
 * @param xx TODO
 * @return TODO
 */
int foo3(char ch, int xx)
{
}
};

/**
 * CFoo
 * TODO: DESCRIPTION
 * @param arg TODO
 * @return TODO
 */
CFoo::CFoo(int arg) {
}

/**
 * ~CFoo
 * TODO: DESCRIPTION
 * @return TODO
 */
CFoo::~CFoo() {
}

/**
 * foo1
 * TODO: DESCRIPTION
 * @param arg TODO
 * @param arg2 TODO
 * @return TODO
 */
int CFoo::foo1(int arg, int arg2)
{
}

/**
 * foo2
 * TODO: DESCRIPTION
 * @return TODO
 */
int CFoo::foo2()
{
}

/**
 * operator +
 * TODO: DESCRIPTION
 * @return TODO
 */
int CFoo::operator +()
{
}

/**
 * func
 * TODO: DESCRIPTION
 * @return TODO
 */
map<string, int> func()
{
	// some codes
}

/**
 * some_func
 * TODO: DESCRIPTION
 * @return TODO
 */
int some_func(void)
{
}

class some_class_declaration;

int some_func_declaration();
