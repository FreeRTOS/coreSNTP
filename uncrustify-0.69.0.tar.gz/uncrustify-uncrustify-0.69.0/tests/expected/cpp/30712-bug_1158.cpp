void Class1::Func(void)
{
	while (Next());
}
