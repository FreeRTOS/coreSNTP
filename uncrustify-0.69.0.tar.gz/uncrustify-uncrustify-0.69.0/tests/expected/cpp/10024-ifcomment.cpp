if (true)               // indent_relative_single_line_comments = false
    return;
if (foo)     // true
{
    bar(1);  // action 1
}
else         // false
{
    bar(2);  // action 2
}
