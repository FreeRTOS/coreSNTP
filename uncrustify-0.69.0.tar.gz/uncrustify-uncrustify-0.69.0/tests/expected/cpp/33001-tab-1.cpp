/* test of
 * indent_with_tabs = 1
 * indent_columns   = 11
 * the source has NO <TAB>
 */
{
	   int x;
	   int y;
}
