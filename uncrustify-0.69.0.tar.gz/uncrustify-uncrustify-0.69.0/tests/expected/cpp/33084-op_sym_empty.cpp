class Foo
{
bool operator== ( const Foo & other ) const;
Bar & operator*() const;
};
