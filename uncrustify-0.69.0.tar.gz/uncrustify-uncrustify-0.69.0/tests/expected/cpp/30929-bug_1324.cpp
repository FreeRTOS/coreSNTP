{
        for (i = 0;i < 10;i++)
        {
                b = i + 1;
        }
        for (;; )
        {
                b = b + 1;
        }
}
