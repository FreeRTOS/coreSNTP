void whatever() {
	SomeStruct a = SomeStruct{1, 2, 3};

	someFuncCall(SomeStruct{4, 5, 6});
}

namespace foo {
int bar();
};
