void f() {
	auto x = "\ttest\t \t \t \t\t...   ???";
}
