namespace Test1 { namespace Test {

CodeConstructor::CodeConstructor()
{
}

CodeConstructor::getSomething()
{
        return 0;
}

}}
