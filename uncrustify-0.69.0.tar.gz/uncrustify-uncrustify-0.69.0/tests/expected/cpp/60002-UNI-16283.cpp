// It is deleting the space after the pointer marker
void foo()
{
    extern void BillboardRenderer_RenderMultiple(const RenderBatchedData & renderData, ShaderChannelMask channels);
}
