using Foo = std::function<void(const bool)>;
