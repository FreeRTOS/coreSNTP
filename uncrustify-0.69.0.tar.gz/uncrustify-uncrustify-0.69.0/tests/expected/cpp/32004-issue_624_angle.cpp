auto c = a < b >> 1;
auto c = a < b;
