namespace cats
{ // rule

int count;
void meow();

}

namespace dogs { // drool

int count;
void bark();

}

namespace pigs {

int count;
void oink();

}

namespace owls
{

int count;
void hoot();

}
