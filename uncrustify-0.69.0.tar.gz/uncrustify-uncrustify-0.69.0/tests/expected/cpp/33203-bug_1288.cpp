friend std::ostream& operator<<(std::ostream& os, const ScriptingObjectPtr& o);
