decltype(i * d) prod = i * d;
decltype(i + d) sum;
