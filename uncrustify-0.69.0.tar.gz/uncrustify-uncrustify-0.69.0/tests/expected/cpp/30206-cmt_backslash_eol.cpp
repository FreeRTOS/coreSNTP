foo();
// test \
// blah();
bar();
