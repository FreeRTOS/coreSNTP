Foo::Foo() :
        Base(12),
        mValue(24) {
    func();
}
