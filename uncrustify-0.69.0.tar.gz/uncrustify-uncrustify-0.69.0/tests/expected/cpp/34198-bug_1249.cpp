friend class ::GameObject;
void GameObject::Foo();

auto x = ::GlobalFunc();

friend void ::testing::PrintDebugInformationForFakesInUse();

template<class TransferFunction>
void ::DateTime::Transfer(TransferFunction & transfer)
{
}
