// 3456789=123456789=123456789=123456789=123456789=123456789=12
std::map<int, std::string>
FOO::foo(
        int         key,
        std::string value )
{
    return std::map<int, std::string>( key, value );
}
