int main()
{
        auto lambda2 = [&]()
        {
                code();
        };
}
