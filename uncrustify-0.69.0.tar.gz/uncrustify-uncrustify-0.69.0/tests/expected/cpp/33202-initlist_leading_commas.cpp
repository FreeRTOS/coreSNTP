MyClass::MyClass(Type *var1, Type *var2) :
    BaseClass(parent),
    mVar1(var1),
    mVar2(var2) {
}
