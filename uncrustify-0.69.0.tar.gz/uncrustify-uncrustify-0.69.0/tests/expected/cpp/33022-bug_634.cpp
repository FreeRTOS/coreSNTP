__attribute__((visibility ("default"))) NSString* i;
extern "C" NSString* i;
