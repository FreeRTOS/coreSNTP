class
		MyClass
{
public:
    void f123(MyType1 AAAAAAAAAAAAAA, MyType2 BBBBBBBBBBBB,
                    int XXXXXXXXXXXXXXX);
    void foo(::some::very::looong::_and::complicated::name::MyType& a,
                    ::some::very::looong::_and::complicated::name::MyType& b,
                    some::very::looong::_and::complicated::name::MyType& c);
};
