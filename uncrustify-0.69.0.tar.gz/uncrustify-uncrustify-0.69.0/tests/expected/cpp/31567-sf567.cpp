package com.temp.test;

public class Database
{
private Database(String fileName)
{
	readConfig(fileName, "asdfasdf", 1);
	readConfig(ame,      "aasdf",    1);

	Database::readConfig(fileName, "asdfasdf", 1);
	Database::readConfig(ame,      "aasdf",    1);

	::readConfig(fileName, "asdfasdf", 1);
	::readConfig(ame,      "aasdf",    1);
}
}
