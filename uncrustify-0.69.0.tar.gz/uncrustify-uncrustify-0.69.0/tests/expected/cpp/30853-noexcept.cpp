foo() noexcept;
