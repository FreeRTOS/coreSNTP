int variable1 = items_array[index<int>()];
