namespace Constants
{
double PI = 3.14;
}
int factor = 41;
double result = Constants::PI * factor;
