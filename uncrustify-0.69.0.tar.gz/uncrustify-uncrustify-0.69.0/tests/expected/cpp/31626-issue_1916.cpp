int x;

decltype (x)  y;
decltype (x)  z = 5;

decltype (char{5})  a = 'a';

using x_t = decltype (x);
