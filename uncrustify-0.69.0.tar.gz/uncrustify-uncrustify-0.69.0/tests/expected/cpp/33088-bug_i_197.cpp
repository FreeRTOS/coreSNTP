struct A {int a;};
