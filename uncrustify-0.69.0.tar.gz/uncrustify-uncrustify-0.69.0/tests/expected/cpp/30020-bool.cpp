bool foo(char c)
{
   if (c == 'a')
   {
      return(true);
   }
   else
   {
      return(false);
   }
}
