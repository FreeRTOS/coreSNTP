// make sure that we ignore sp_inside_angle=remove if it will cause a digraph to be created

ops.pProgressCallback = reinterpret_cast<      ::ProgressCallback*>(progressCallback);
ops.pProgressCallback = reinterpret_cast< ::ProgressCallback*>(progressCallback);
ops.pProgressCallback = reinterpret_cast<::ProgressCallback*>(progressCallback);
ops.pProgressCallback = reinterpret_cast<ProgressCallback*>(progressCallback);
ops.pProgressCallback = reinterpret_cast<ProgressCallback*>(progressCallback);
