void foo1( int ( & x ) [ 2 ] );
void foo2( int ( & x ) [ 2 ] );
