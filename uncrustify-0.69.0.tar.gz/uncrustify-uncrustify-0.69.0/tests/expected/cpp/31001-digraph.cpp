x = reinterpret_cast< ::Symbol *>();

int b()
{
   char f<: 32 :> = < % 0 % >;
}
