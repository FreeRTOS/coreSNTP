void func() {
}

// **ABC**
void func() { }
// *INDENT-ON*

void func() {
}
