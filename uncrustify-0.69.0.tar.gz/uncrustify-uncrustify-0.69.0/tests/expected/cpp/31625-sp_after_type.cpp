static int x1;
unsigned long int y1 = (unsigned short)0;
const int foo1(int x);

foo((const int*)0);
static_cast<long long>(0);

static int x2;
unsigned long int y2  =  (  unsigned short  )  0;
const int  foo2  (  int x  );

foo  (  (  const int*  )  0  );
static_cast  <  long long  >  (  0  );
