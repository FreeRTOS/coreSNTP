// I want to keeep the function call indented
Thingy
    .Select()
    .ToList();

// it works with a var
var x = Thingy
    .Select()
    .ToList();
