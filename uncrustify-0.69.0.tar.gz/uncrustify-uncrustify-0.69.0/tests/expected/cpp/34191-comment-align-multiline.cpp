#include <stdio.h>

void function()
{
	printf( "Hello World\n" );
	/*
	   output_comment_multi_simple to test replacement of \r\n to \n keep the
	   following \r:
	   //test
	   /// Another comment
	   //end test
	 */
}
