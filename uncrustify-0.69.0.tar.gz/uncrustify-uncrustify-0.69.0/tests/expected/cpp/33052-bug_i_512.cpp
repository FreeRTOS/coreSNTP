template<typename TType>
class TTypeSpecialization1<TType>
{
}
