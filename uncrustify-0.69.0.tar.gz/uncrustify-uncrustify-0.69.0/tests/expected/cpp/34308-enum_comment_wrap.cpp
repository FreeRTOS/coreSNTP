enum class Eee
{
    Foo,
    AnotherFoo, // comment
    Bar,
    DifferentBar
};
