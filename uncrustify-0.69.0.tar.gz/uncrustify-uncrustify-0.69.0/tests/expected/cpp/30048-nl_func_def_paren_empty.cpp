void LocalClass::LocalClass()
{
	int Function(
		)
	{
		return 0;
	}

	int Function(
		)
	{
		return 0;
	}

	int Function()
	{
		return 0;
	}
}